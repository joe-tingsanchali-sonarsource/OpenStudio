
// Generated from modelica.g4 by ANTLR 4.13.2


#include "modelicaVisitor.h"


